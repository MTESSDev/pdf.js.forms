/* This is an automatically generated file. Do not edit. */

/* ETen-B5-V */

static const pdf_range cmap_ETen_B5_V_ranges[] = {
{41291,41291,13646},
{41306,41306,13743},
{41308,41308,13745},
{41309,41310,130},
{41313,41314,134},
{41317,41318,138},
{41321,41322,142},
{41325,41326,146},
{41329,41330,150},
{41333,41334,154},
{41337,41338,158},
{41443,41443,13647},
{50916,50917,14097},
};

static pdf_cmap cmap_ETen_B5_V = {
	{ -1, pdf_drop_cmap_imp },
	/* cmapname */ "ETen-B5-V",
	/* usecmap */ "ETen-B5-H", NULL,
	/* wmode */ 1,
	/* codespaces */ 0, {
		{ 0, 0, 0 },
	},
	13, 13, (pdf_range*)cmap_ETen_B5_V_ranges,
	0, 0, NULL, /* xranges */
	0, 0, NULL, /* mranges */
	0, 0, NULL, /* table */
	0, 0, 0, NULL /* splay tree */
};
